/** Automatically generated file. DO NOT MODIFY */
package com.example.notas_android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}